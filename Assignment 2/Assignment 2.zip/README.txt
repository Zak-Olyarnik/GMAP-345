Zak Olyarnik
CS-345
Assignment 2

Move Silver around the 2D environment, jumping on the platforms and using psychic pulses to push the item.  This game is especially for Dippy after he said that Sonic '06 was bad.

Move forward/backward = Right/Left arrow keys
Jump = Up arrow key
Attack = Down arrow key

Silver sprites taken from yosharioiii's DeviantArt: http://yosharioiii.deviantart.com/art/Sonic-Battle-Custom-Silver-Sprites-INCOMPLETE-328873332
Item sprite taken from http://i31.tinypic.com/rhljee.png
All textures created from original Photoshop designs