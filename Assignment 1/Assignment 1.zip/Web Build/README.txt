Zak Olyarnik
CS-345
Assignment 1

Move your capsule character between the four rooms by jumping over the low walls in between.

Move forward/backward = Up/Down arrow keys
Rotate camera = Left/Right arrow keys
Jump = Spacebar

All models created from Unity primitives
All textures created from original Photoshop designs